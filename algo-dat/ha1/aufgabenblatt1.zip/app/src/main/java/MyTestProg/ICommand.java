package MyTestProg;

public interface ICommand {
    String execute();
    String description();
}